namespace Refactorings_and_Quick_Fixes.MoveItHere
{
    public class ForTheFolderMove
    {
        
    }
}