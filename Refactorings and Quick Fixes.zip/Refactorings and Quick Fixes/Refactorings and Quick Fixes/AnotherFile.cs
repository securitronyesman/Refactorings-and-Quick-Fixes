namespace Refactorings_and_Quick_Fixes;

public class AnotherFile
{
    
}